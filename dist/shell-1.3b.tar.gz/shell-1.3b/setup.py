from distutils.core import setup

setup(name='shell', version='1.3b', py_modules=['shell'])