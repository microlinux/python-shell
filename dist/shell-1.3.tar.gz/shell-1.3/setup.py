from distutils.core import setup

setup(name='shell', version='1.3', py_modules=['shell'])