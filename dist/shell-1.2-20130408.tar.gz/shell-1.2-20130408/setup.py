from distutils.core import setup

setup(name='shell', version='1.2-20130408', py_modules=['shell'])