from distutils.core import setup

setup(name='shell', version='1.1_BETA-20130402', py_modules=['shell'])